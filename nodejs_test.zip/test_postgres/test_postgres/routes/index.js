var express = require('express');
var router = express.Router();
var moment = require('moment');
var pg = require('pg');

router.get('/', function(req, res, next) {
  //レンダリングする箇所
  res.render('index', { title: 'Express' });
});

// router.post('/', function(req, res, next) {
//   //検証やテストのロジック  
//   var title = req.body.title;
//   var createdAt = moment().format('YYYY-MM-DD HH:mm:ss'); 
//   console.log(title);
//   console.log(createdAt);
// });

router.post('/update', function(req, res, next) {
  var value = req.body.updateValue;

  //DBとのコネクションストリング
  const config = {
    host: 'localhost',
    user: 'postgres',     
    password: 'P@ssw0rd',
    database: 'sample',
    port: 5432,
    ssl: false
  };

  var client = new pg.Client(config);

  client.connect(err => {
      if (err) throw err;
      else {
          updateTable(client,value);
      }
  });
});

function updateTable(client,val) {
  const query = `INSERT INTO testtable1 (no) VALUES ($1);`;

  client
      .query(query,[val])
      .then(() => {
          console.log('更新できました');
          client.end(console.log('Closed client connection'));
      })
      .catch(err => console.log(err))
      .then(() => {
          console.log('Finished execution, exiting now');
          process.exit();
      });
}

module.exports = router;
